package test;

import java.util.Scanner;

public class GPS {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("img path>> ");
		String path = sc.nextLine();

		javaxt.io.Image image = new javaxt.io.Image(path); // JavaXT

		double[] gps = image.getGPSCoordinate();
		if (gps != null) {
			System.out.println("========================================");
			System.out.println("GPS Coordinate(latitude, longitude)");
			System.out.println(gps[1] + ", " + gps[0]);
			// System.out.println("GPS Datum: " + image.getGPSDatum());
		}

		System.out.println("========================================");
		if (gps[1] > 33.100000 && gps[1] < 38.450000 && gps[0] > 125.066667 && gps[0] < 131.872222)
			if (gps[1] > 37.413294 && gps[1] < 37.715133 && gps[0] > 126.734086 && gps[0] < 127.269311)
				System.out.println("Location: Seoul");
			else if (gps[1] > 33.0 && gps[1] < 38.9 && gps[0] > 124.5 && gps[0] < 132.0)
				System.out.println("Location: Gyeonggi-do");
			else
				System.out.println("Other");
		else
			System.out.println("Not in S.Korea");

		sc.close();
	}

}
